#version 120
/* Aurora Fantasy - gbuffers_terrain.vsh
Render: Almost everything

in2bubble - Based on MakeUp by KDXavier - GNU Lesser General Public License v3.0
*/

#define GBUFFER_TERRAIN
#define FOLIAGE_V
#define EMMISIVE_V

#include "/common/solid_blocks_vertex.glsl"
