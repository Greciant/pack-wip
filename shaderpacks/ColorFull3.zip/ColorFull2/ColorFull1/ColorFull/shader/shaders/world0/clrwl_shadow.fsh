#version 400 compatibility
#define DIMENSION_OVERWORLD

#include "/program/clrwl_shadow.fsh"