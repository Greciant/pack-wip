#include "/lib/all_the_libs.glsl"

// TODO: Handle this more elegantly
#undef PBR_SPECULAR

flat in vec4 glcolor_flat;

#include "/global/gbuffers.fsh"

/* DRAWBUFFERS:0 */
layout(location = 0) out vec4 Color;

void main() {
    Color = glcolor_flat;

    // Workaround for selection box not rendering on optifine. I hate optifine.
    #ifdef GBUFFERS_TEXTURED
        Color *= texture(gtexture, texcoord);
    #endif

    if(Color.a < alphaTestRef) {
        discard;
    }

    #if MC_VERSION >= 11700
        if(renderStage == MC_RENDER_STAGE_OUTLINE) {
            Color.a = 1;
            #if OUTLINE_MODE == 1
                // Multicolor outline based on screen position and time
                vec2 screenPos = gl_FragCoord.xy / resolution;
                float hue = atan(screenPos.y - 0.5, screenPos.x - 0.5) / 3.14159 * 0.5 + 0.5;
                hue += frameTimeCounter * 0.5; // Animated rainbow
                hue = mod(hue, 1.0);
                
                // HSV to RGB conversion
                float x = cos(hue * 6.28318);
                float y = sin(hue * 6.28318);
                Color.rgb = vec3(
                    0.5 + 0.5 * cos(hue * 6.28318),
                    0.5 + 0.5 * cos((hue - 0.333) * 6.28318),
                    0.5 + 0.5 * cos((hue - 0.667) * 6.28318)
                );
                Color.rgb *= 1.5; // Brighter colors
            #endif
        }
    #endif
    
    Color.rgb = to_linear(Color.rgb);
    vec3 PlayerPos = view_player(ViewPos, false);
    vec3 TweakedLM = tweak_lightmap(PlayerPos, LightmapCoords, texcoord, gl_FragCoord.xy);
    Color.xyz *= TweakedLM;
}
